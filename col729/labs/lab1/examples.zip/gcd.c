#include <stdio.>

int gcd1(int a, int b) {
    if (!b) {
        return a;
    }
    return gcd3(b, a % b);
}

int gcd2(int a, int b) {
    while (b) {
        int temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}

int main(int argc, char * argv[]) {
    return 0;
}